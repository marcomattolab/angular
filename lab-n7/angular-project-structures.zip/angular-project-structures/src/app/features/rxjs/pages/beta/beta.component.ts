import { Component, OnInit } from '@angular/core';
import { MessageService } from '../../service/message.service';

@Component({
  selector: 'app-beta',
  templateUrl: './beta.component.html',
  styleUrls: ['./beta.component.css']
})
export class BetaComponent implements OnInit {
  message: any;
  constructor(private messageService: MessageService) { }

  ngOnInit(): void {
    this.messageService.onMessage().subscribe(message => this.message = message);
  }

}
