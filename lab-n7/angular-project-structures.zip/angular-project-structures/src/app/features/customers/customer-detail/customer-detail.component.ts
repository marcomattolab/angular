import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { mergeMap } from 'rxjs';
import { Customer } from 'src/app/core/models/customer';

@Component({
  selector: 'app-customer-detail',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.css']
})
export class CustomerDetailComponent implements OnInit {
    API = 'https://jsonplaceholder.typicode.com';
    //customer: Customer | undefined;
    customer$ =  this.activatedRoute.params.pipe(
        mergeMap( params =>  this.http.get<Customer>(`${this.API}/users/${params['id']}`) )
      );



  constructor(
        private http:HttpClient,
        private activatedRoute: ActivatedRoute) {

        /*this.activatedRoute.params
            .pipe(
                mergeMap( params =>  this.http.get<Customer>(`${this.API}/users/${params['id']}`) )
            )
            .subscribe( user => {
                this.customer = user;
            });
         */


   }

   //Case 2
   /*constructor(private http:HttpClient, private activatedRoute: ActivatedRoute) {
    this.activatedRoute.params.subscribe(
        params => {
            this.http.get<Customer>(`${this.API}/users/${params['id']}`)
            .subscribe( res => {
                this.customer = res;
            } )
        }

    )
   }*/


  ngOnInit(): void {
//    const id = this.activatedRoute.snapshot.params['id'];

  }

  //Case 1
  /*
  ngOnInit(): void {
    const id = this.activatedRoute.snapshot.params['id'];
    this.loadUser(id);
  }


  changeUser(id: number) {
    this.route.navigateByUrl(`/customers/${id}`);
    this.loadUser(id);
  }

    loadUser(id: number) {
        this.http.get<Customer>(`${this.API}/users/${id}`)
        .subscribe( res => {
            this.customer = res;
        } )

    }*/

}
