import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Customer } from 'src/app/core/models/customer';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
    API = 'https://jsonplaceholder.typicode.com';
    customers: Customer[] | undefined;


  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get<Customer[]>(`${this.API}/users`).subscribe(
        res => this.customers = res
    );

  }

}
