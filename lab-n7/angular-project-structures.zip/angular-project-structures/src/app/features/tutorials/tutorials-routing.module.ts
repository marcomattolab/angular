import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddTutorialsComponent } from './add-tutorials/add-tutorials.component';
import { TutorialsComponent } from './tutorials.component';

const routes: Routes = [
    { path: '', component: TutorialsComponent },
    { path: 'add', component: AddTutorialsComponent }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TutorialsRoutingModule { }
