import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TutorialsRoutingModule } from './tutorials-routing.module';
import { TutorialsComponent } from './tutorials.component';
import { AddTutorialsComponent } from './add-tutorials/add-tutorials.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TutorialsDetailsComponent } from './tutorials-details/tutorials-details.component';


@NgModule({
  declarations: [
    TutorialsComponent,
    AddTutorialsComponent,
    TutorialsDetailsComponent
  ],
  imports: [
    CommonModule,
    TutorialsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ]
})
export class TutorialsModule { }
