export class Customer {
    id?: any;
    name?: string;
    username?: string;
    email?: string;
    phone?: string;
  }
