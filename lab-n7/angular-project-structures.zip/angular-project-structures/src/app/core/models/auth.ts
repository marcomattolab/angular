export const ADMIN = 'admin';
export const MODERATOR = 'moderator';
export const GUEST = 'guest';
export type UserRoles = typeof ADMIN | typeof MODERATOR | typeof GUEST;

export interface Auth {
   token: string;
   displayName: string;
   role: UserRoles;
}
