import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { BehaviorSubject, Observable, map } from 'rxjs';
import { Auth, UserRoles } from '../models/auth';

@Injectable({ providedIn: 'root' })
export class AuthService {
    auth$: BehaviorSubject<Auth> = new BehaviorSubject<Auth>({token:'-1', displayName:'Guest', role: 'guest'});

    constructor(private http: HttpClient, private router: Router) {
        //Only for DEMO (Forced Test)
        //localStorage.setItem('auth', JSON.stringify({token:'-1', displayName:'Guest', role: 'guest'}));
        let authString = localStorage.getItem('auth');
        if(authString)
            this.auth$.next(JSON.parse(authString));
    }

    login(username: string, password: string): void {
        const params = new HttpParams()
        .set('username', username).set('password', password);

        this.http.get<Auth>('http://localhost:3000/login', { params })
            .subscribe(res => {
                this.auth$.next(res);
                localStorage.setItem('auth', JSON.stringify(res));
                this.router.navigateByUrl('users');
                }
            );
    }

    logout(): void {
        this.auth$.next({token:'-1', displayName:'Guest', role: 'guest'});
        localStorage.removeItem('auth');
        this.router.navigateByUrl('/');
    }

    get isLogged$(): Observable<boolean> {
        return this.auth$.pipe(map(value => !!value) );
    }

    get role$(): Observable<UserRoles> {
        return this.auth$.pipe( map(auth => auth?.role) );
    }

    get token$(): Observable<string> {
        return this.auth$.pipe( map(auth => auth?.token) );
    }

    get displayName$(): Observable<string> {
        return this.auth$.pipe( map(auth => auth?.displayName));
    }

}
