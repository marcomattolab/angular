import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { map, of, Subject, switchMap, tap } from 'rxjs';
import { Auth } from '../models/auth';

@Injectable({
  providedIn: 'root'
})
export class JwtService {
  token$: Subject<string> = new Subject();

  constructor(private http: HttpClient, private router: Router) { }

  /*login(username:string, password:string): void {

    const params = new HttpParams()
    .set('username', username)
    .set('password', password);

    this.http.get<Auth>('http://localhost:3000/login', { params })
        .pipe(
            map( auth => auth.token )
        )
        .subscribe( (res) => {
            console.log("token: " + res);
            this.token$.next(res);
            console.log("User is logged in");
            localStorage.setItem('token', JSON.stringify(res));
            this.router.navigateByUrl('reactiveform');
            }
        );



  }*/

  logout(): void{
    this.token$.next("");
    localStorage.removeItem('token');
    this.router.navigateByUrl('/');
  }


  getTokenLS() {
    return localStorage.getItem('token');
  }

  isAuthenticated(): boolean {
    const tk = this.getTokenLS();
    console.log("localStorage.getToken() ===> "+ tk);
    console.log("authenticated ===> "+ !!tk);
    return !!tk;
  }


  login(username:string, password:string): void {
    const params = new HttpParams()
        .set('username', username)
        .set('password', password);

    this.http.get<Auth>('http://localhost:3000/login', { params })
        .pipe(
            switchMap(auth => {
                return of(auth.token);
            }),
            tap(token => {
                this.token$.next(token);
                localStorage.setItem('token', JSON.stringify(token));
                this.router.navigateByUrl('reactiveform');
            })
        )
        .subscribe(
            (isLogged) => {
                console.log('User is logged in');
                //this.authenticated = isLogged;
            }
        );
  }



}
