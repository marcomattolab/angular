import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmailFormComponent } from './features/email-form/email-form.component';
import { LoginComponent } from './features/login/login.component';
import { MeteoComponent } from './features/meteo/meteo.component';
import { ReactiveFormComponent } from './features/reactive-form/reactive-form.component';
import { ListRxjsComponent } from './features/rxjs/pages/list/listRxjs.component';


const appRoutes: Routes = [
  { path: '', redirectTo: 'tutorials', pathMatch: 'full' },
  { path: 'listRxjs', component: ListRxjsComponent },
  { path: 'reactiveform', component: ReactiveFormComponent },
  { path: 'meteo', component: MeteoComponent },
  { path: 'cva', component: EmailFormComponent },
  { path: 'tutorials', loadChildren: () => import('./features/tutorials/tutorials.module').then(m => m.TutorialsModule) },
  { path: 'customers', loadChildren: () => import('./features/customers/customers.module').then(m => m.CustomersModule) },
  { path: 'login', component: LoginComponent },
  //{ path: 'tutorials',   loadChildren: () => TutorialsModule },

];

@NgModule({
  imports: [RouterModule.forRoot(appRoutes, {enableTracing: false, useHash: false})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
