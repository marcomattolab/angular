import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListRxjsComponent } from './features/rxjs/pages/list/listRxjs.component';
import { AlfaComponent } from './features/rxjs/pages/alfa/alfa.component';
import { BetaComponent } from './features/rxjs/pages/beta/beta.component';
import { ReactiveFormComponent } from './features/reactive-form/reactive-form.component';
import { MeteoComponent } from './features/meteo/meteo.component';
import { EmailFormComponent } from './features/email-form/email-form.component';
import { EmailSelectorComponent } from './features/email-selector/email-selector.component';
import { LoginComponent } from './features/login/login.component';
import { TokenInterceptor } from './core/auth/token.interceptor';
import { ErrorInterceptor } from './core/auth/error.interceptor';


@NgModule({
    declarations: [
        AppComponent,
        AlfaComponent,
        BetaComponent,
        ReactiveFormComponent,
        MeteoComponent,
        EmailFormComponent,
        EmailSelectorComponent,
        ListRxjsComponent,
        LoginComponent,
    ],
    providers: [
        {provide:HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi:true},
        {provide:HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi:true}

    ],
    bootstrap: [AppComponent],
    imports: [
        BrowserModule,
        AppRoutingModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
    ]
})
export class AppModule { }
