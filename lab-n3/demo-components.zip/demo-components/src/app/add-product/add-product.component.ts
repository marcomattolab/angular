import { Component, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent {
    @Output() newProductEvent =  new EventEmitter();

    aggiungiProdotto(value: string){
      this.newProductEvent.emit(value);
    }
}
