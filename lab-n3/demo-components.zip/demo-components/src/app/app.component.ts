import { Component, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit, OnDestroy, OnChanges{
  title = 'demo-components';
  //prodotti = ['Penna USB', 'Hard Disk', 'Monitor'];
  prodotti?: string [];

  constructor(){
    console.log("1. Chiamato il costruttore della classe AppComponent");
    //Inserisco i riferimenti ai services tramatile la DI
  }

  ngOnChanges(changes: SimpleChanges): void {
     console.log(" Chiamato il metodo ngOnChanges");
  }

  ngOnDestroy(): void {
    console.log(" Chiamato il metodo ngOnDestroy");
  }

  ngOnInit(): void {
    console.log("2. Chiamato il metodo ngOnInit");
    this.prodotti = ['Penna USB', 'Hard Disk', 'Monitor'];
  }

  pushItem(prodotto: string) {
    this.prodotti?.push(prodotto);
  }

}
