import { Component, OnInit } from '@angular/core';
import { fromEvent, of , interval, Observable, Subscription } from 'rxjs';
import {
  find,
  map,
  filter,
  switchMap,
  delay
} from 'rxjs/operators';

const wait2Secs = (val:number []) =>
  new Promise((resolve) => setTimeout(() => resolve(`Result: ${val}`), 5000));

// faking network request for save
const saveLocation = (location: any) => {
  return of(location).pipe(delay(500));
};

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'demo-rxjs';
  sub?: Subscription;

  ngOnInit() {
    const stream$ = of([1, 2, 3], [4, 5, 6], [9, 10 , 11])
      .pipe(
        //map((x) => wait2Secs(x)),
        //mergeMap((x) => x),
        switchMap((x) => x), // [1,3,4,5,6,7,9,10,11]
        filter( (x) => x%2 === 0)
        //find( (x) => x%2 === 1 )
      )
      .subscribe((next) => console.log(`next: ${next}`));

      const click$ = fromEvent(document, 'click')
      click$.subscribe( r => console.log('E arrivato il seguente evento di click: ', r))


      //interva con subscription
      const numbers$ = interval(2000).pipe( map( x => x*2 ));
      this.sub = numbers$.subscribe( (x) => console.log(x) );

  }

  handleClick() {
    console.log('Button clicked!');
    // Unsubscribe di numbers$
    this.sub?.unsubscribe();
    console.log('Observable interval has been unsubscribed!');
  }


  saveLocation(location: any) {
    return of(location).pipe(delay(500));
  }

}
