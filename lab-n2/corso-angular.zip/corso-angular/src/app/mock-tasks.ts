import { Task } from "./task";

export const TASKS: Task[] = [
  { id: 12, name: 'Task 1' },
  { id: 13, name: 'Task 2' },
  { id: 14, name: 'Task 3' },
  { id: 15, name: 'Task 4' },
  { id: 16, name: 'Task 5' },
  { id: 17, name: 'Task 6' }

]
