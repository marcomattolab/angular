import { Component } from '@angular/core';
import { TASKS } from '../mock-tasks';
import { Task } from '../task';

@Component({
  selector: 'app-tasks',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent {
    sottotitolo = "Ecco i task da fare";
    tasks = TASKS;

    selectedTask?: Task;

    constructor(){}

    onSelect(task: Task){
      this.selectedTask = task;
    }

}
