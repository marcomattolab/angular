
export interface User {
  id: number;
  name: string;
  description: string;
  roleId: number;
}
